// BaaS Test App - Main JavaScript

// Global state
let currentUser = null;
let isLoginMode = true;
let todos = [];
let users = [];
let products = [];
let blogPosts = [];
let files = [];

// Sample data
const sampleData = {
  todos: [
    { id: 1, title: 'Complete BaaS platform testing', description: 'Test all CRUD operations', completed: false, createdAt: new Date() },
    { id: 2, title: 'Review code quality', description: 'Check for any bugs or issues', completed: true, createdAt: new Date() },
    { id: 3, title: 'Deploy to production', description: 'Deploy the final version', completed: false, createdAt: new Date() }
  ],
  users: [
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin', status: 'active' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'User', status: 'active' },
    { id: 3, name: 'Bob Johnson', email: 'bob@example.com', role: 'User', status: 'inactive' }
  ],
  products: [
    { id: 1, name: 'Laptop', description: 'High-performance laptop', price: 999.99, category: 'electronics', image: '💻' },
    { id: 2, name: 'T-Shirt', description: 'Comfortable cotton t-shirt', price: 19.99, category: 'clothing', image: '👕' },
    { id: 3, name: 'JavaScript Book', description: 'Learn JavaScript programming', price: 39.99, category: 'books', image: '📚' }
  ],
  blogPosts: [
    { id: 1, title: 'Getting Started with BaaS', content: 'Learn how to use our Backend-as-a-Service platform...', author: 'John Doe', status: 'published', createdAt: new Date() },
    { id: 2, title: 'Advanced Features Guide', content: 'Explore advanced features and capabilities...', author: 'Jane Smith', status: 'draft', createdAt: new Date() }
  ],
  files: [
    { id: 1, name: 'document.pdf', size: '2.5 MB', type: 'document', icon: '📄' },
    { id: 2, name: 'image.jpg', size: '1.2 MB', type: 'image', icon: '🖼️' },
    { id: 3, name: 'video.mp4', size: '15.8 MB', type: 'video', icon: '🎥' }
  ]
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
});

function initializeApp() {
  // Load sample data
  todos = [...sampleData.todos];
  users = [...sampleData.users];
  products = [...sampleData.products];
  blogPosts = [...sampleData.blogPosts];
  files = [...sampleData.files];

  // Check if user is logged in
  const savedUser = localStorage.getItem('currentUser');
  if (savedUser) {
    currentUser = JSON.parse(savedUser);
    showAuthenticatedState();
  } else {
    showAuthSection();
  }

  // Setup navigation
  setupNavigation();
  
  // Setup event listeners
  setupEventListeners();
}

function setupNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const section = this.getAttribute('data-section');
      showSection(section);
      
      // Update active nav link
      navLinks.forEach(l => l.classList.remove('active'));
      this.classList.add('active');
    });
  });
}

function setupEventListeners() {
  // File upload
  const fileInput = document.getElementById('fileInput');
  if (fileInput) {
    fileInput.addEventListener('change', handleFileUpload);
  }
}

function showSection(sectionName) {
  // Hide all sections
  const sections = document.querySelectorAll('.section');
  sections.forEach(section => section.classList.remove('active'));
  
  // Show target section
  const targetSection = document.getElementById(sectionName + 'Section');
  if (targetSection) {
    targetSection.classList.add('active');
    
    // Load section data
    switch(sectionName) {
      case 'dashboard':
        loadDashboard();
        break;
      case 'todos':
        loadTodos();
        break;
      case 'users':
        loadUsers();
        break;
      case 'products':
        loadProducts();
        break;
      case 'blog':
        loadBlogPosts();
        break;
      case 'files':
        loadFiles();
        break;
    }
  }
}

// Authentication functions
function showAuth() {
  showAuthSection();
}

function showAuthSection() {
  document.getElementById('authSection').classList.add('active');
  document.getElementById('loginBtn').style.display = 'inline-flex';
  document.getElementById('userInfo').style.display = 'none';
  
  // Hide other sections
  const sections = document.querySelectorAll('.section:not(#authSection)');
  sections.forEach(section => section.classList.remove('active'));
}

function showAuthenticatedState() {
  document.getElementById('authSection').classList.remove('active');
  document.getElementById('loginBtn').style.display = 'none';
  document.getElementById('userInfo').style.display = 'flex';
  document.getElementById('userName').textContent = currentUser.name;
  document.getElementById('dashboardUserName').textContent = currentUser.name;
  
  // Show dashboard by default
  showSection('dashboard');
}

function switchAuthMode() {
  isLoginMode = !isLoginMode;
  const title = document.getElementById('authTitle');
  const subtitle = document.getElementById('authSubtitle');
  const btnText = document.getElementById('authBtnText');
  const switchText = document.getElementById('authSwitchText');
  const confirmPasswordGroup = document.getElementById('confirmPasswordGroup');
  
  if (isLoginMode) {
    title.textContent = 'Login';
    subtitle.textContent = 'Welcome back! Please sign in to your account.';
    btnText.textContent = 'Login';
    switchText.innerHTML = 'Don\'t have an account? <a href="#" onclick="switchAuthMode()">Sign up</a>';
    confirmPasswordGroup.style.display = 'none';
  } else {
    title.textContent = 'Sign Up';
    subtitle.textContent = 'Create your account to get started.';
    btnText.textContent = 'Sign Up';
    switchText.innerHTML = 'Already have an account? <a href="#" onclick="switchAuthMode()">Sign in</a>';
    confirmPasswordGroup.style.display = 'block';
  }
}

function handleAuth(event) {
  event.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;
  const rememberMe = document.getElementById('rememberMe').checked;
  
  // Show loading
  const btnText = document.getElementById('authBtnText');
  const spinner = document.getElementById('authSpinner');
  btnText.style.display = 'none';
  spinner.style.display = 'inline-block';
  
  // Simulate API call
  setTimeout(() => {
    if (isLoginMode) {
      // Login
      if (email && password) {
        currentUser = {
          id: 1,
          name: email.split('@')[0],
          email: email
        };
        
        if (rememberMe) {
          localStorage.setItem('currentUser', JSON.stringify(currentUser));
        }
        
        showAuthenticatedState();
        showToast('success', 'Login Successful', 'Welcome back!');
      } else {
        showToast('error', 'Login Failed', 'Please check your credentials.');
      }
    } else {
      // Sign up
      if (password !== confirmPassword) {
        showToast('error', 'Sign Up Failed', 'Passwords do not match.');
        btnText.style.display = 'inline';
        spinner.style.display = 'none';
        return;
      }
      
      if (email && password) {
        currentUser = {
          id: Date.now(),
          name: email.split('@')[0],
          email: email
        };
        
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showAuthenticatedState();
        showToast('success', 'Sign Up Successful', 'Account created successfully!');
      } else {
        showToast('error', 'Sign Up Failed', 'Please fill in all fields.');
      }
    }
    
    btnText.style.display = 'inline';
    spinner.style.display = 'none';
  }, 1000);
}

function logout() {
  currentUser = null;
  localStorage.removeItem('currentUser');
  showAuthSection();
  showToast('success', 'Logged Out', 'You have been successfully logged out.');
}

function socialLogin(provider) {
  showToast('info', 'Social Login', `${provider} login would be implemented here.`);
}

function togglePassword() {
  const passwordInput = document.getElementById('password');
  const toggle = event.target;
  
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    toggle.innerHTML = '<i class="fas fa-eye-slash"></i>';
  } else {
    passwordInput.type = 'password';
    toggle.innerHTML = '<i class="fas fa-eye"></i>';
  }
}

function toggleConfirmPassword() {
  const confirmPasswordInput = document.getElementById('confirmPassword');
  const toggle = event.target;
  
  if (confirmPasswordInput.type === 'password') {
    confirmPasswordInput.type = 'text';
    toggle.innerHTML = '<i class="fas fa-eye-slash"></i>';
  } else {
    confirmPasswordInput.type = 'password';
    toggle.innerHTML = '<i class="fas fa-eye"></i>';
  }
}

// Dashboard functions
function loadDashboard() {
  // Update counts
  document.getElementById('todoCount').textContent = todos.length;
  document.getElementById('userCount').textContent = users.length;
  document.getElementById('productCount').textContent = products.length;
  document.getElementById('postCount').textContent = blogPosts.length;
  
  // Update activity list
  const activityList = document.getElementById('activityList');
  activityList.innerHTML = `
    <div class="activity-item">
      <i class="fas fa-plus-circle"></i>
      <span>Welcome to your dashboard!</span>
      <small>Just now</small>
    </div>
    <div class="activity-item">
      <i class="fas fa-tasks"></i>
      <span>Added ${todos.length} todos</span>
      <small>Recently</small>
    </div>
    <div class="activity-item">
      <i class="fas fa-users"></i>
      <span>Managing ${users.length} users</span>
      <small>Recently</small>
    </div>
  `;
}

// Todo functions
function loadTodos() {
  const todoList = document.getElementById('todoList');
  if (todos.length === 0) {
    todoList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks"></i>
        <h3>No todos yet</h3>
        <p>Create your first todo to get started!</p>
      </div>
    `;
    return;
  }
  
  todoList.innerHTML = todos.map(todo => `
    <div class="todo-item">
      <input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''} 
             onchange="toggleTodo(${todo.id})">
      <div class="todo-content">
        <div class="todo-title ${todo.completed ? 'completed' : ''}">${todo.title}</div>
        <div class="todo-description">${todo.description}</div>
      </div>
      <div class="todo-actions">
        <button class="btn btn-warning" onclick="editTodo(${todo.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-error" onclick="deleteTodo(${todo.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join('');
}

function showTodoModal(todo = null) {
  const isEdit = todo !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Edit Todo' : 'Add Todo';
  
  document.getElementById('modalBody').innerHTML = `
    <form onsubmit="saveTodo(event, ${isEdit ? todo.id : 'null'})">
      <div class="form-group">
        <label for="todoTitle">Title</label>
        <input type="text" id="todoTitle" value="${isEdit ? todo.title : ''}" required>
      </div>
      <div class="form-group">
        <label for="todoDescription">Description</label>
        <textarea id="todoDescription" rows="3">${isEdit ? todo.description : ''}</textarea>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full">
          ${isEdit ? 'Update Todo' : 'Add Todo'}
        </button>
      </div>
    </form>
  `;
  
  showModal();
}

function saveTodo(event, todoId) {
  event.preventDefault();
  
  const title = document.getElementById('todoTitle').value;
  const description = document.getElementById('todoDescription').value;
  
  if (todoId) {
    // Edit existing todo
    const todoIndex = todos.findIndex(t => t.id === todoId);
    if (todoIndex !== -1) {
      todos[todoIndex] = { ...todos[todoIndex], title, description };
      showToast('success', 'Todo Updated', 'Todo has been updated successfully.');
    }
  } else {
    // Add new todo
    const newTodo = {
      id: Date.now(),
      title,
      description,
      completed: false,
      createdAt: new Date()
    };
    todos.push(newTodo);
    showToast('success', 'Todo Added', 'New todo has been added successfully.');
  }
  
  closeModal();
  loadTodos();
  loadDashboard();
}

function toggleTodo(todoId) {
  const todo = todos.find(t => t.id === todoId);
  if (todo) {
    todo.completed = !todo.completed;
    showToast('success', 'Todo Updated', `Todo marked as ${todo.completed ? 'completed' : 'pending'}.`);
    loadTodos();
    loadDashboard();
  }
}

function editTodo(todoId) {
  const todo = todos.find(t => t.id === todoId);
  if (todo) {
    showTodoModal(todo);
  }
}

function deleteTodo(todoId) {
  if (confirm('Are you sure you want to delete this todo?')) {
    todos = todos.filter(t => t.id !== todoId);
    showToast('success', 'Todo Deleted', 'Todo has been deleted successfully.');
    loadTodos();
    loadDashboard();
  }
}

function filterTodos() {
  const search = document.getElementById('todoSearch').value.toLowerCase();
  const filter = document.getElementById('todoFilter').value;
  
  let filteredTodos = todos.filter(todo => {
    const matchesSearch = todo.title.toLowerCase().includes(search) || 
                         todo.description.toLowerCase().includes(search);
    const matchesFilter = filter === 'all' || 
                         (filter === 'completed' && todo.completed) ||
                         (filter === 'pending' && !todo.completed);
    return matchesSearch && matchesFilter;
  });
  
  // Update display
  const todoList = document.getElementById('todoList');
  todoList.innerHTML = filteredTodos.map(todo => `
    <div class="todo-item">
      <input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''} 
             onchange="toggleTodo(${todo.id})">
      <div class="todo-content">
        <div class="todo-title ${todo.completed ? 'completed' : ''}">${todo.title}</div>
        <div class="todo-description">${todo.description}</div>
      </div>
      <div class="todo-actions">
        <button class="btn btn-warning" onclick="editTodo(${todo.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-error" onclick="deleteTodo(${todo.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join('');
}

function sortTodos() {
  const sortBy = document.getElementById('todoSort').value;
  
  todos.sort((a, b) => {
    switch(sortBy) {
      case 'newest':
        return new Date(b.createdAt) - new Date(a.createdAt);
      case 'oldest':
        return new Date(a.createdAt) - new Date(b.createdAt);
      case 'title':
        return a.title.localeCompare(b.title);
      default:
        return 0;
    }
  });
  
  loadTodos();
}

// User functions
function loadUsers() {
  const userTableBody = document.getElementById('userTableBody');
  if (users.length === 0) {
    userTableBody.innerHTML = `
      <tr>
        <td colspan="5" class="empty-state">
          <i class="fas fa-users"></i>
          <h3>No users yet</h3>
          <p>Add your first user to get started!</p>
        </td>
      </tr>
    `;
    return;
  }
  
  userTableBody.innerHTML = users.map(user => `
    <tr>
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.role}</td>
      <td><span class="status-badge ${user.status}">${user.status}</span></td>
      <td>
        <button class="btn btn-warning" onclick="editUser(${user.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-error" onclick="deleteUser(${user.id})">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function showUserModal(user = null) {
  const isEdit = user !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Edit User' : 'Add User';
  
  document.getElementById('modalBody').innerHTML = `
    <form onsubmit="saveUser(event, ${isEdit ? user.id : 'null'})">
      <div class="form-group">
        <label for="userName">Name</label>
        <input type="text" id="userName" value="${isEdit ? user.name : ''}" required>
      </div>
      <div class="form-group">
        <label for="userEmail">Email</label>
        <input type="email" id="userEmail" value="${isEdit ? user.email : ''}" required>
      </div>
      <div class="form-group">
        <label for="userRole">Role</label>
        <select id="userRole" required>
          <option value="User" ${isEdit && user.role === 'User' ? 'selected' : ''}>User</option>
          <option value="Admin" ${isEdit && user.role === 'Admin' ? 'selected' : ''}>Admin</option>
        </select>
      </div>
      <div class="form-group">
        <label for="userStatus">Status</label>
        <select id="userStatus" required>
          <option value="active" ${isEdit && user.status === 'active' ? 'selected' : ''}>Active</option>
          <option value="inactive" ${isEdit && user.status === 'inactive' ? 'selected' : ''}>Inactive</option>
        </select>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full">
          ${isEdit ? 'Update User' : 'Add User'}
        </button>
      </div>
    </form>
  `;
  
  showModal();
}

function saveUser(event, userId) {
  event.preventDefault();
  
  const name = document.getElementById('userName').value;
  const email = document.getElementById('userEmail').value;
  const role = document.getElementById('userRole').value;
  const status = document.getElementById('userStatus').value;
  
  if (userId) {
    // Edit existing user
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      users[userIndex] = { ...users[userIndex], name, email, role, status };
      showToast('success', 'User Updated', 'User has been updated successfully.');
    }
  } else {
    // Add new user
    const newUser = {
      id: Date.now(),
      name,
      email,
      role,
      status
    };
    users.push(newUser);
    showToast('success', 'User Added', 'New user has been added successfully.');
  }
  
  closeModal();
  loadUsers();
  loadDashboard();
}

function editUser(userId) {
  const user = users.find(u => u.id === userId);
  if (user) {
    showUserModal(user);
  }
}

function deleteUser(userId) {
  if (confirm('Are you sure you want to delete this user?')) {
    users = users.filter(u => u.id !== userId);
    showToast('success', 'User Deleted', 'User has been deleted successfully.');
    loadUsers();
    loadDashboard();
  }
}

function filterUsers() {
  const search = document.getElementById('userSearch').value.toLowerCase();
  const filter = document.getElementById('userFilter').value;
  
  let filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(search) || 
                         user.email.toLowerCase().includes(search);
    const matchesFilter = filter === 'all' || user.status === filter;
    return matchesSearch && matchesFilter;
  });
  
  // Update display
  const userTableBody = document.getElementById('userTableBody');
  userTableBody.innerHTML = filteredUsers.map(user => `
    <tr>
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.role}</td>
      <td><span class="status-badge ${user.status}">${user.status}</span></td>
      <td>
        <button class="btn btn-warning" onclick="editUser(${user.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn btn-error" onclick="deleteUser(${user.id})">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

// Product functions
function loadProducts() {
  const productGrid = document.getElementById('productGrid');
  if (products.length === 0) {
    productGrid.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-box"></i>
        <h3>No products yet</h3>
        <p>Add your first product to get started!</p>
      </div>
    `;
    return;
  }
  
  productGrid.innerHTML = products.map(product => `
    <div class="product-card">
      <div class="product-image">${product.image}</div>
      <div class="product-content">
        <div class="product-title">${product.name}</div>
        <div class="product-description">${product.description}</div>
        <div class="product-price">$${product.price}</div>
        <div class="product-actions" style="margin-top: 1rem;">
          <button class="btn btn-warning" onclick="editProduct(${product.id})">
            <i class="fas fa-edit"></i> Edit
          </button>
          <button class="btn btn-error" onclick="deleteProduct(${product.id})">
            <i class="fas fa-trash"></i> Delete
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function showProductModal(product = null) {
  const isEdit = product !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Edit Product' : 'Add Product';
  
  document.getElementById('modalBody').innerHTML = `
    <form onsubmit="saveProduct(event, ${isEdit ? product.id : 'null'})">
      <div class="form-group">
        <label for="productName">Name</label>
        <input type="text" id="productName" value="${isEdit ? product.name : ''}" required>
      </div>
      <div class="form-group">
        <label for="productDescription">Description</label>
        <textarea id="productDescription" rows="3">${isEdit ? product.description : ''}</textarea>
      </div>
      <div class="form-group">
        <label for="productPrice">Price</label>
        <input type="number" id="productPrice" step="0.01" value="${isEdit ? product.price : ''}" required>
      </div>
      <div class="form-group">
        <label for="productCategory">Category</label>
        <select id="productCategory" required>
          <option value="electronics" ${isEdit && product.category === 'electronics' ? 'selected' : ''}>Electronics</option>
          <option value="clothing" ${isEdit && product.category === 'clothing' ? 'selected' : ''}>Clothing</option>
          <option value="books" ${isEdit && product.category === 'books' ? 'selected' : ''}>Books</option>
        </select>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full">
          ${isEdit ? 'Update Product' : 'Add Product'}
        </button>
      </div>
    </form>
  `;
  
  showModal();
}

function saveProduct(event, productId) {
  event.preventDefault();
  
  const name = document.getElementById('productName').value;
  const description = document.getElementById('productDescription').value;
  const price = parseFloat(document.getElementById('productPrice').value);
  const category = document.getElementById('productCategory').value;
  
  if (productId) {
    // Edit existing product
    const productIndex = products.findIndex(p => p.id === productId);
    if (productIndex !== -1) {
      products[productIndex] = { ...products[productIndex], name, description, price, category };
      showToast('success', 'Product Updated', 'Product has been updated successfully.');
    }
  } else {
    // Add new product
    const newProduct = {
      id: Date.now(),
      name,
      description,
      price,
      category,
      image: '📦'
    };
    products.push(newProduct);
    showToast('success', 'Product Added', 'New product has been added successfully.');
  }
  
  closeModal();
  loadProducts();
  loadDashboard();
}

function editProduct(productId) {
  const product = products.find(p => p.id === productId);
  if (product) {
    showProductModal(product);
  }
}

function deleteProduct(productId) {
  if (confirm('Are you sure you want to delete this product?')) {
    products = products.filter(p => p.id !== productId);
    showToast('success', 'Product Deleted', 'Product has been deleted successfully.');
    loadProducts();
    loadDashboard();
  }
}

function filterProducts() {
  const search = document.getElementById('productSearch').value.toLowerCase();
  const filter = document.getElementById('productFilter').value;
  
  let filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(search) || 
                         product.description.toLowerCase().includes(search);
    const matchesFilter = filter === 'all' || product.category === filter;
    return matchesSearch && matchesFilter;
  });
  
  // Update display
  const productGrid = document.getElementById('productGrid');
  productGrid.innerHTML = filteredProducts.map(product => `
    <div class="product-card">
      <div class="product-image">${product.image}</div>
      <div class="product-content">
        <div class="product-title">${product.name}</div>
        <div class="product-description">${product.description}</div>
        <div class="product-price">$${product.price}</div>
        <div class="product-actions" style="margin-top: 1rem;">
          <button class="btn btn-warning" onclick="editProduct(${product.id})">
            <i class="fas fa-edit"></i> Edit
          </button>
          <button class="btn btn-error" onclick="deleteProduct(${product.id})">
            <i class="fas fa-trash"></i> Delete
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

// Blog functions
function loadBlogPosts() {
  const blogList = document.getElementById('blogList');
  if (blogPosts.length === 0) {
    blogList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-blog"></i>
        <h3>No blog posts yet</h3>
        <p>Create your first blog post to get started!</p>
      </div>
    `;
    return;
  }
  
  blogList.innerHTML = blogPosts.map(post => `
    <div class="blog-post">
      <div class="blog-title">${post.title}</div>
      <div class="blog-excerpt">${post.content.substring(0, 150)}...</div>
      <div class="blog-meta">
        <span>By ${post.author}</span>
        <span class="blog-status ${post.status}">${post.status}</span>
      </div>
      <div class="blog-actions" style="margin-top: 1rem;">
        <button class="btn btn-warning" onclick="editBlogPost(${post.id})">
          <i class="fas fa-edit"></i> Edit
        </button>
        <button class="btn btn-error" onclick="deleteBlogPost(${post.id})">
          <i class="fas fa-trash"></i> Delete
        </button>
      </div>
    </div>
  `).join('');
}

function showBlogModal(post = null) {
  const isEdit = post !== null;
  document.getElementById('modalTitle').textContent = isEdit ? 'Edit Blog Post' : 'New Blog Post';
  
  document.getElementById('modalBody').innerHTML = `
    <form onsubmit="saveBlogPost(event, ${isEdit ? post.id : 'null'})">
      <div class="form-group">
        <label for="blogTitle">Title</label>
        <input type="text" id="blogTitle" value="${isEdit ? post.title : ''}" required>
      </div>
      <div class="form-group">
        <label for="blogContent">Content</label>
        <textarea id="blogContent" rows="6">${isEdit ? post.content : ''}</textarea>
      </div>
      <div class="form-group">
        <label for="blogAuthor">Author</label>
        <input type="text" id="blogAuthor" value="${isEdit ? post.author : currentUser.name}" required>
      </div>
      <div class="form-group">
        <label for="blogStatus">Status</label>
        <select id="blogStatus" required>
          <option value="draft" ${isEdit && post.status === 'draft' ? 'selected' : ''}>Draft</option>
          <option value="published" ${isEdit && post.status === 'published' ? 'selected' : ''}>Published</option>
        </select>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full">
          ${isEdit ? 'Update Post' : 'Create Post'}
        </button>
      </div>
    </form>
  `;
  
  showModal();
}

function saveBlogPost(event, postId) {
  event.preventDefault();
  
  const title = document.getElementById('blogTitle').value;
  const content = document.getElementById('blogContent').value;
  const author = document.getElementById('blogAuthor').value;
  const status = document.getElementById('blogStatus').value;
  
  if (postId) {
    // Edit existing post
    const postIndex = blogPosts.findIndex(p => p.id === postId);
    if (postIndex !== -1) {
      blogPosts[postIndex] = { ...blogPosts[postIndex], title, content, author, status };
      showToast('success', 'Post Updated', 'Blog post has been updated successfully.');
    }
  } else {
    // Add new post
    const newPost = {
      id: Date.now(),
      title,
      content,
      author,
      status,
      createdAt: new Date()
    };
    blogPosts.push(newPost);
    showToast('success', 'Post Created', 'New blog post has been created successfully.');
  }
  
  closeModal();
  loadBlogPosts();
  loadDashboard();
}

function editBlogPost(postId) {
  const post = blogPosts.find(p => p.id === postId);
  if (post) {
    showBlogModal(post);
  }
}

function deleteBlogPost(postId) {
  if (confirm('Are you sure you want to delete this blog post?')) {
    blogPosts = blogPosts.filter(p => p.id !== postId);
    showToast('success', 'Post Deleted', 'Blog post has been deleted successfully.');
    loadBlogPosts();
    loadDashboard();
  }
}

function filterBlogPosts() {
  const search = document.getElementById('blogSearch').value.toLowerCase();
  const filter = document.getElementById('blogFilter').value;
  
  let filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(search) || 
                         post.content.toLowerCase().includes(search);
    const matchesFilter = filter === 'all' || post.status === filter;
    return matchesSearch && matchesFilter;
  });
  
  // Update display
  const blogList = document.getElementById('blogList');
  blogList.innerHTML = filteredPosts.map(post => `
    <div class="blog-post">
      <div class="blog-title">${post.title}</div>
      <div class="blog-excerpt">${post.content.substring(0, 150)}...</div>
      <div class="blog-meta">
        <span>By ${post.author}</span>
        <span class="blog-status ${post.status}">${post.status}</span>
      </div>
      <div class="blog-actions" style="margin-top: 1rem;">
        <button class="btn btn-warning" onclick="editBlogPost(${post.id})">
          <i class="fas fa-edit"></i> Edit
        </button>
        <button class="btn btn-error" onclick="deleteBlogPost(${post.id})">
          <i class="fas fa-trash"></i> Delete
        </button>
      </div>
    </div>
  `).join('');
}

// File functions
function loadFiles() {
  const fileGrid = document.getElementById('fileGrid');
  if (files.length === 0) {
    fileGrid.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-file-upload"></i>
        <h3>No files yet</h3>
        <p>Upload your first file to get started!</p>
      </div>
    `;
    return;
  }
  
  fileGrid.innerHTML = files.map(file => `
    <div class="file-item">
      <div class="file-icon">${file.icon}</div>
      <div class="file-name">${file.name}</div>
      <div class="file-size">${file.size}</div>
      <div class="file-actions" style="margin-top: 0.5rem;">
        <button class="btn btn-error" onclick="deleteFile(${file.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join('');
}

function showFileUpload() {
  document.getElementById('modalTitle').textContent = 'Upload File';
  
  document.getElementById('modalBody').innerHTML = `
    <form onsubmit="handleFileUpload(event)">
      <div class="form-group">
        <label for="fileInput">Choose File</label>
        <input type="file" id="fileInput" name="file" required>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full">
          <i class="fas fa-upload"></i> Upload File
        </button>
      </div>
    </form>
  `;
  
  showModal();
}

function handleFileUpload(event) {
  event.preventDefault();
  
  const fileInput = document.getElementById('fileInput');
  const file = fileInput.files[0];
  
  if (file) {
    // Simulate file upload
    showToast('info', 'Uploading...', 'Please wait while your file is being uploaded.');
    
    setTimeout(() => {
      const newFile = {
        id: Date.now(),
        name: file.name,
        size: formatFileSize(file.size),
        type: getFileType(file.type),
        icon: getFileIcon(file.type)
      };
      
      files.push(newFile);
      showToast('success', 'Upload Successful', 'File has been uploaded successfully.');
      closeModal();
      loadFiles();
    }, 2000);
  }
}

function deleteFile(fileId) {
  if (confirm('Are you sure you want to delete this file?')) {
    files = files.filter(f => f.id !== fileId);
    showToast('success', 'File Deleted', 'File has been deleted successfully.');
    loadFiles();
  }
}

function filterFiles() {
  const search = document.getElementById('fileSearch').value.toLowerCase();
  const filter = document.getElementById('fileFilter').value;
  
  let filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(search);
    const matchesFilter = filter === 'all' || file.type === filter;
    return matchesSearch && matchesFilter;
  });
  
  // Update display
  const fileGrid = document.getElementById('fileGrid');
  fileGrid.innerHTML = filteredFiles.map(file => `
    <div class="file-item">
      <div class="file-icon">${file.icon}</div>
      <div class="file-name">${file.name}</div>
      <div class="file-size">${file.size}</div>
      <div class="file-actions" style="margin-top: 0.5rem;">
        <button class="btn btn-error" onclick="deleteFile(${file.id})">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join('');
}

// Utility functions
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getFileType(mimeType) {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.includes('pdf') || mimeType.includes('document')) return 'document';
  return 'other';
}

function getFileIcon(mimeType) {
  if (mimeType.startsWith('image/')) return '🖼️';
  if (mimeType.startsWith('video/')) return '🎥';
  if (mimeType.includes('pdf')) return '📄';
  if (mimeType.includes('document')) return '📝';
  return '📁';
}

// Modal functions
function showModal() {
  document.getElementById('modalOverlay').classList.add('active');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active');
}

// Toast notification functions
function showToast(type, title, message) {
  const toastContainer = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  const icon = type === 'success' ? 'fas fa-check-circle' : 
               type === 'error' ? 'fas fa-exclamation-circle' : 
               type === 'warning' ? 'fas fa-exclamation-triangle' : 
               'fas fa-info-circle';
  
  toast.innerHTML = `
    <div class="toast-icon">
      <i class="${icon}"></i>
    </div>
    <div class="toast-content">
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    </div>
    <button class="toast-close" onclick="removeToast(this)">
      <i class="fas fa-times"></i>
    </button>
  `;
  
  toastContainer.appendChild(toast);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast);
    }
  }, 5000);
}

function removeToast(button) {
  const toast = button.closest('.toast');
  if (toast && toast.parentNode) {
    toast.parentNode.removeChild(toast);
  }
}

// Navigation toggle for mobile
function toggleNav() {
  const navMenu = document.getElementById('navMenu');
  navMenu.classList.toggle('active');
}

// API simulation functions (for testing BaaS integration)
function simulateApiCall(endpoint, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate API response
      const response = {
        success: true,
        data: data || { message: 'API call successful' },
        timestamp: new Date().toISOString()
      };
      
      if (Math.random() < 0.1) { // 10% chance of error
        reject(new Error('Simulated API error'));
      } else {
        resolve(response);
      }
    }, 1000);
  });
}

// Export functions for BaaS integration
window.BaaSTestApp = {
  // Data getters
  getTodos: () => todos,
  getUsers: () => users,
  getProducts: () => products,
  getBlogPosts: () => blogPosts,
  getFiles: () => files,
  
  // API simulation
  simulateApiCall,
  
  // Current user
  getCurrentUser: () => currentUser,
  
  // Data manipulation
  addTodo: (todo) => todos.push(todo),
  addUser: (user) => users.push(user),
  addProduct: (product) => products.push(product),
  addBlogPost: (post) => blogPosts.push(post),
  addFile: (file) => files.push(file)
};
